package lego;

public enum Tema {
    Architecture,
    Batman,
    Botanical_Collection,
    BrickHeadz,
    City,
    Classic,
    Creator_3in1,
    DC,
    Disney,
}
